import React from "react";
import RaitingUsers from "./components/RaitingUsers";

import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";

function App() {
  return (
    <div className="container">
      <RaitingUsers />
    </div>
  );
}

export default App;
