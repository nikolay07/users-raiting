import React from "react";
import PropTypes from "prop-types";

const User = ({ id, handleClick, name, avatar, color, speed, time }) => {
  const blue = color.blue;
  const orange = color.orange;
  return (
    <div id={id} className="user" onClick={handleClick}>
      <div className="user__logo">
        <span id="num_color" style={{ color: blue }}>
          {id}
        </span>
        <img
          src={avatar}
          alt="avatar"
          id="av_color"
          style={{ borderColor: blue }}
        />
      </div>
      <div className="user__info">
        <div className="user__info_name">
          <span>{name}</span>
        </div>
        <div className="user__info_speed">
          <span id="time_color">00:00.000</span>
          <span className="speed">| {speed}км/ч</span>
        </div>
        <div className="user__info_penalty">
          <span id="time-penalty" style={{ color: orange }}>
            штрафное время {time}0:00.000
          </span>
        </div>
      </div>
    </div>
  );
};

export default User;

User.propTypes = {
  id: PropTypes.number.isRequired,
  handleClick: PropTypes.func.isRequired,
  name: PropTypes.string.isRequired,
  avatar: PropTypes.string.isRequired,
  color: PropTypes.object.isRequired,
  speed: PropTypes.number.isRequired,
  time: PropTypes.number.isRequired,
};
