const UserInterface = {
  color: { blue: "blue", orange: "orange" },
  name: "Михаил Лихачев",
  speed: 80,
  time: 0,
  avatar: require("../img/loader.gif"),
};

export const userList = Array(50).fill(UserInterface);
